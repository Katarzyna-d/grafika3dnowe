This repository contains the basic starting  project for my 3D Graphics Programming course. 
